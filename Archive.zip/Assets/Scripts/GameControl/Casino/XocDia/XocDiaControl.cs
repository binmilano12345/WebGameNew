﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using DG.Tweening;
using UnityEngine.UI;
using AppConfig;
using System;
using DataBase;
using System.Linq;
using Us.Mobile.Utilites;

public class XocDiaControl : BaseCasino
{
	public static XocDiaControl instance;
	const string ANIM_XOC_DIA = "xoc";
	const string ANIM_MO_BAT = "mobat";
	const string ANIM_UP_BAT = "upbat";
	void Awake ()
	{
		instance = this;
	}
	#region UI

	[SerializeField]
	TimeCountDown timeCountDown;

	[Header ("DAT CUOC")]
	/// <summary>
	/// 0-chan, 1-le, 2-4do, 3-4trang, 4-3do, 5-3trang
	/// </summary>
	[SerializeField]
	Button[] btn_cua_cuoc;
	/// <summary>
	/// 0-chan, 1-le, 2-4do, 3-4trang, 4-3do, 5-3trang
	/// </summary>
	[SerializeField]
	GameObject[] win_effect;
	/// <summary>
	/// 0-chan, 1-le, 2-4do, 3-4trang, 4-3do, 5-3trang
	/// </summary>
	[SerializeField]
	Text[] txt_sum_money;
	/// <summary>
	/// 0-chan, 1-le, 2-4do, 3-4trang, 4-3do, 5-3trang
	/// </summary>
	[SerializeField]
	Text[] txt_me_money;
	[SerializeField]
	UIButton btn_dat_x2, btn_dat_lai, btn_huy_cuoc, btn_lam_cai, btn_huy_cai;
	[SerializeField]
	Transform img_girl;
	[SerializeField]
	GameObject obj_pre_chip;
	//load prefab chip

	[SerializeField]
	Image[] img_dices;

	[Header ("BET")]
	[SerializeField]
	Toggle[] tg_bet_money;
	[SerializeField]
	Text[] txt_bet_money;
	[Header ("HISTORY")]
	[SerializeField]
	Image[] chanleImgs;
	[SerializeField]
	Animator animXocDia;
	[SerializeField]
	Image img_bat;
	[SerializeField]
	Text chanTextHis;
	[SerializeField]
	Text leTextHis;

	#endregion

	#region Variable
	int numbChanHis = 0;
	int numbLeHis = 0;
	bool IsDatCuoc = false;
	long CurrentBetMoney = 0;
	long[] SelectBetMoney = new long[4];
	long[] sum_money = new long[6];
	long[] sum_me_money = new long[6];

	#endregion

	void Start ()
	{
		base.Start ();
		int i = 0;
		for (i = 0; i < tg_bet_money.Length; i++) {
			tg_bet_money [i].name = i + "";
			tg_bet_money [i].onValueChanged.AddListener (delegate {
				OnChangeBet (tg_bet_money [i].gameObject);
			});
		}
		for (i = 0; i < btn_cua_cuoc.Length; i++) {
			btn_cua_cuoc [i].name = i + "";
			btn_cua_cuoc [i].onClick.AddListener (delegate {
				OnClickDatCuoc (btn_cua_cuoc [i].gameObject);
			});
		}
	}

	#region CLICK

	void OnChangeBet (GameObject obj)
	{
		Debug.LogError ("==========>  " + obj.name);
		int index = int.Parse (obj.name);
		if (index >= tg_bet_money.Length - 1)
			CurrentBetMoney = ClientConfig.UserInfo.CASH_FREE;
		else
			CurrentBetMoney = SelectBetMoney [index];
	}

	void OnClickDatCuoc (GameObject obj)
	{
		Debug.LogError ("OnClickDatCuoc==========>  " + obj.name);
		int cua = int.Parse (obj.name);

		if (IsDatCuoc) {
			SendData.onsendXocDiaDatCuoc ((byte)cua, CurrentBetMoney); 
		}
	}

	public void OnClickDatX2 ()
	{
		SendData.onsendGapDoi ();
	}

	public void OnClickDatLai ()
	{
		SendData.onsendDatLai ();
	}

	public void OnClickHuyCuoc ()
	{
		SendData.onsendHuyCuoc ();
	}

	public void OnClickLamCai ()
	{
		SendData.onsendLamCai ();
	}

	public void OnClickHuyCai ()
	{
	}

	public void OnClickShowHistory ()
	{
		if (!isRunShow)
			return;
		isRunShow = false;
		if (isShow) {
			tf_parent_ls_item.DOLocalMoveY (VT_Y, 0.6f).OnComplete (() => {
				isRunShow = true;
			});
		} else {
			Vector3 vt = tf_parent_ls_item.localPosition;
			VT_Y = vt.y;
			int cout = tf_parent_ls_item.childCount;
			vt.y += (cout - 1) * 40;
			tf_parent_ls_item.DOLocalMoveY (vt.y, 0.6f).OnComplete (() => {
				isRunShow = true;
			});
		}
		if (listItemHis.Count > 0) {
			listItemHis [listItemHis.Count - 1].SetArrowUp (isShow);
		}
		isShow = !isShow;
	}

	#endregion

	#region Handle Lich Su Van Choi

	[SerializeField]
	Transform tf_parent_ls_image, tf_parent_ls_item;
	List<Image> listImage = new List<Image> ();
	List<ItemHistoryXocDia> listItemHis = new List<ItemHistoryXocDia> ();

	bool isShow = false;
	float VT_Y = -140;
	bool isRunShow = true;

	void UpdateHistory (int resultRed)
	{
		#region Update His Image
		if (listImage.Count < 24) {
			LoadAssetBundle.LoadPrefab (BundleName.PREFAPS, PrefabsName.PRE_IMAGE_LICH_SU_XOC_DIA, (objPre) => {
				Image obj = objPre.GetComponent<Image> ();
				obj.transform.SetParent (tf_parent_ls_image);
				obj.transform.localScale = Vector3.one;
				LoadAssetBundle.LoadSprite (obj, BundleName.UI, (resultRed % 2 != 0 ? UIName.UI_XD_RED : UIName.UI_XD_WHITE));
				listImage.Add (obj);
				if (resultRed % 2 != 0) {
					numbLeHis++;
					leTextHis.text = "<color = yellow>" + numbLeHis + "</color>\nLẻ";
				} else {
					numbChanHis++;
					chanTextHis.text = "<color = yellow>" + numbChanHis + "</color>\nChẵn";
				}
			});
		} else {
			for (int i = 0; i < listImage.Count; i++) {
				Image objImg = listImage [i];
				if (i < listImage.Count - 1) {
					objImg.sprite = listImage [i + 1].sprite;
				} else {
					LoadAssetBundle.LoadSprite (objImg, BundleName.UI, (resultRed % 2 != 0 ? UIName.UI_XD_RED : UIName.UI_XD_WHITE));
					if (resultRed % 2 != 0) {
						numbLeHis++;
						leTextHis.text = "Lẻ \n" + numbLeHis;
					} else {
						numbChanHis++;
						chanTextHis.text = "Chẵn \n" + numbChanHis;
					}
				}
			}
		}
		#endregion

		#region Update item His
		if (listItemHis.Count < 9) {
			LoadAssetBundle.LoadPrefab (BundleName.PREFAPS, PrefabsName.PRE_ITEM_LICH_SU_XOC_DIA, (objPre) => {
				for (int i = 0; i < listItemHis.Count; i++) {
					listItemHis [i].SetShowArrow (false);
				}
				ItemHistoryXocDia objItem = objPre.GetComponent<ItemHistoryXocDia> ();
				objItem.transform.SetParent (tf_parent_ls_item);
				objItem.transform.SetAsFirstSibling ();
				objItem.transform.localScale = Vector3.one;

				objItem.SetInfo (resultRed);
				objItem.SetShowArrow (true);
				listItemHis.Add (objItem);
			});
		} else {
			for (int i = 0; i < listItemHis.Count; i++) {
				ItemHistoryXocDia objHIs = listItemHis [i];
				if (i < listItemHis.Count - 1) {
					objHIs.SetInfo (listItemHis [i + 1].result);
				} else {
					objHIs.SetInfo (resultRed);
				}
			}
		}
		#endregion
	}

	#endregion

	private void SetActiveButton (bool isGapDoi, bool isDatLai, bool isHuyCuoc, bool isLamCai, bool isHuyCai)
	{
		btn_dat_x2.gameObject.SetActive (isGapDoi);
		btn_dat_lai.gameObject.SetActive (isDatLai);
		btn_huy_cuoc.gameObject.SetActive (isHuyCuoc);
		btn_lam_cai.gameObject.SetActive (isLamCai);
		btn_huy_cai.gameObject.SetActive (isHuyCai);
	}

	private void SetEnableButton (bool isGapDoi, bool isDatLai, bool isHuyCuoc, bool isLamCai, bool isHuyCai)
	{
		btn_dat_x2.enabled = isGapDoi;
		btn_dat_lai.enabled = isDatLai;
		btn_huy_cuoc.enabled = isHuyCuoc;
		btn_lam_cai.enabled = isLamCai;
		btn_huy_cai.enabled = isHuyCai;
	}

	internal override void OnJoinTablePlaySuccess (Message message)
	{
		try {
			sbyte rule = message.reader ().ReadByte ();
			SetLuatChoi (rule);
			string master = message.reader ().ReadUTF ();
			int len = message.reader ().ReadByte ();
			int timeTurn = message.reader ().ReadInt ();
			isPlaying = message.reader ().ReadBoolean ();
			for (int i = 0; i < len; i++) {
				PlayerData pl = new PlayerData ();
				pl.Name = message.reader ().ReadUTF ();
				pl.DisplaName = message.reader ().ReadUTF ();
				pl.Avata_Link = message.reader ().ReadUTF ();
				pl.Avata_Id = message.reader ().ReadInt ();
				pl.SitOnSever = message.reader ().ReadByte ();
				pl.Money = message.reader ().ReadLong ();
				pl.IsReady = message.reader ().ReadBoolean ();
				pl.FolowMoney = message.reader ().ReadLong ();
				pl.IsMaster = pl.Name.Equals (master);
				if (isPlaying) {
					pl.IsReady = false;
				}
				GameObject objPlayer = Instantiate (GameControl.instance.objPlayer);
				objPlayer.transform.SetParent (GetParentPlayer ());
				objPlayer.transform.localScale = Vector3.one;
				BasePlayer plUI = objPlayer.GetComponent<BasePlayer> ();
				plUI.SetInfo (pl.Name, pl.Money, pl.IsMaster, pl.IsReady, pl.Avata_Id);
				if (pl.Name.Equals (ClientConfig.UserInfo.UNAME)) {
					playerMe = plUI;
				}
				objPlayer.SetActive (false);
				var match = ListPlayer.FirstOrDefault (item => item.NamePlayer == pl.Name);
					
				if (match == null) {
					ListPlayer.Add (plUI);
				} else {
					Destroy (plUI);
				}

				OnJoinTableSuccess (master);
				SortSitPlayer ();
			}
		} catch (Exception ex) {
			Debug.LogException (ex);
		}
	}

	internal override void OnJoinTableSuccess (string master)
	{
		base.OnJoinTableSuccess (master);
		if (master.Equals ("")) {
			SetActiveButton (true, true, true, true, false);
			img_girl.gameObject.SetActive (true);
		} else {
			img_girl.gameObject.SetActive (true);
			btn_lam_cai.gameObject.SetActive (false);
			if (ClientConfig.UserInfo.UNAME.Equals (master)) {
				SetActiveButton (false, false, false, false, true);
			} else {
				SetActiveButton (true, true, true, false, false);
			}
			for (int i = 0; i < ListPlayer.Count; i++) {
				if (ListPlayer [i].NamePlayer.Equals (master)) {
					ListPlayer [i].SetShowMaster (true);
					if (i == 0) {
						img_girl.gameObject.SetActive (true);
					}
				} else {
					ListPlayer [i].SetShowMaster (false);
				}
			}
		}
	}

	internal override void SetMaster (String nick)
	{
		OnJoinTableSuccess (nick);
	}

	internal override void OnTimeAuToStart (int time)
	{
		PopupAndLoadingScript.instance.toast.showToast (ClientConfig.Language.GetText ("xd_cho_van_moi"), 5);
		timeCountDown.SetTime (time);
		img_bat.enabled = true;
		animXocDia.Play (ANIM_UP_BAT);
		SetEnableButton (false, false, false, true, false);
	}

	internal void OnBeGinXocDia (int time)
	{
		PopupAndLoadingScript.instance.toast.showToast (ClientConfig.Language.GetText ("xd_nha_cai_xoc"), 5);
		timeCountDown.SetTime (0);
		img_bat.enabled = false;
		animXocDia.Play (ANIM_XOC_DIA);
	}

	internal void OnXocDia_DatCuoc (Message message)
	{
		string nick = message.reader ().ReadUTF ();
		sbyte cua = message.reader ().ReadByte ();
		long money = message.reader ().ReadLong ();
		int typeCHIP = message.reader ().ReadByte ();

		XocDiaPlayer pl = (XocDiaPlayer)GetPlayerWithName (nick);
		if (pl != null) {
			pl.ActionChipDatCuoc (cua, obj_pre_chip);
		}
		sum_money [cua] += money;
		txt_sum_money [cua].text = MoneyHelper.FormatMoneyNormal (sum_money [cua]);
		if (nick.Equals (ClientConfig.UserInfo.UNAME)) {
			sum_me_money [cua] += money;
			txt_me_money [cua].text = MoneyHelper.FormatMoneyNormal (sum_me_money [cua]);
		}
	}

	internal void OnXocDia_DatX2 (Message message)
	{
		string nick = message.reader ().ReadUTF ();
		sbyte socua = message.reader ().ReadByte ();
		XocDiaPlayer pl = (XocDiaPlayer)GetPlayerWithName (nick);
		for (int i = 0; i < socua; i++) {
			sbyte cua = message.reader ().ReadByte ();
			if (pl != null) {
				pl.ActionChipDatX2 (cua);
			}

			sum_money [cua] *= 2;
			txt_sum_money [cua].text = MoneyHelper.FormatMoneyNormal (sum_money [cua]);
			if (nick.Equals (ClientConfig.UserInfo.UNAME)) {
				sum_me_money [cua] *= 2;
				txt_me_money [cua].text = MoneyHelper.FormatMoneyNormal (sum_me_money [cua]);
			}
		}
	}
		
	internal void OnXocDia_DatLai (Message message)
	{
		string nick = message.reader().ReadUTF();
		sbyte socua = message.reader().ReadByte();
		XocDiaPlayer pl = (XocDiaPlayer)GetPlayerWithName (nick);
		for (int i = 0; i < socua; i++) {
			sbyte cua = message.reader ().ReadByte ();
			sbyte a = message.reader ().ReadByte ();
			if (a == 1) {
				sbyte soloaichip = message.reader ().ReadByte ();
				for (int j = 0; j < soloaichip; j++) {
					sbyte loaichip = message.reader ().ReadByte ();
					int sochip = message.reader ().ReadInt ();
					for (int k = 0; k < sochip; k++) {
						pl.ActionChipDatCuoc (cua, obj_pre_chip);
					}
				}
			}
		}
	}

	internal void OnBeGinXocDia_TG_DatCuoc (int time)
	{
		PopupAndLoadingScript.instance.toast.showToast (ClientConfig.Language.GetText ("xd_bd_dat_cuoc"), 5);
		timeCountDown.SetTime (time);
		SetEnableButton (true, true, true, false, false);
	}

	internal void OnXocDia_TG_DungCuoc (Message message)
	{
		SetEnableButton (true, true, true, false, false);
		try {
			int time = message.reader ().ReadByte ();
			PopupAndLoadingScript.instance.toast.showToast (ClientConfig.Language.GetText ("xd_nha_cai_dung_cuoc"), 5);
			timeCountDown.SetTime (time);
		} catch (Exception e) {
		}
	}

	internal void OnBeGinXocDia_MoBat (int quando)
	{
		timeCountDown.SetTime (0);
		animXocDia.Play (ANIM_MO_BAT);
		SetEnableButton (false, false, false, false, false);
		Debug.LogError ("so quan do:   " + quando);
		for (int i = 0; i < img_dices.Length; i++) {
			LoadAssetBundle.LoadSprite(img_dices[i], BundleName.UI, i < quando ? UIName.UI_XD_RED : UIName.UI_XD_WHITE);
		}
		UpdateHistory (quando);
	}

	internal void OnFinishGame (Message message)
	{
		try {
//			dangchoi = false;
			int cua1 = message.reader ().ReadByte ();
			int cua2 = message.reader ().ReadByte ();
//			set_anim_cuato(cua1);
//			set_anim_cuanho(cua2);

			int size = message.reader ().ReadByte ();
			for (int i = 0; i < size; i++) {
				string _name = message.reader ().ReadUTF ();
				long moneyEarn = message.reader ().ReadLong ();
				XocDiaPlayer pl = (XocDiaPlayer) GetPlayerWithName (_name);
				if (pl != null) {
					if (moneyEarn > 0) {
						pl.SetRank (1);
					} else {//thua
						pl.SetRank (6);
					}
					pl.SetEffect ((moneyEarn > 0 ? "+" : "") + MoneyHelper.FormatMoneyNormal (moneyEarn));
					pl.IsReady = false;
				}
			}

//			movemoneyFinishGame(cua1, cua2);
		} catch (Exception e) {
			Debug.LogException (e);
		}
	}

	internal void OnXocDiaUpdateCua (Message message)
	{
		try {
			for (int i = 0; i < sum_money.Length; i++) {
				sum_money [i] = 0;
				sum_me_money [i] = 0;
			}
			string nick = message.reader ().ReadUTF ();
			bool isMe = nick.Equals (ClientConfig.UserInfo.UNAME);
			for (int i = 0; i < 6; i++) {
				sum_money [i] = message.reader ().ReadLong ();
				sum_me_money [i] = message.reader ().ReadLong ();
				txt_sum_money [i].text = MoneyHelper.FormatMoneyNormal (sum_money [i]);
				if (isMe) {
					txt_me_money [i].text = MoneyHelper.FormatMoneyNormal (sum_me_money [i]);
				}
			}
		} catch (Exception e) {
			Debug.LogException (e);
		}
	}

	internal void OnXocDiaHuyCuoc (Message message)
	{
		try {
			string nick = message.reader ().ReadUTF ();
			long moneycua0 = message.reader ().ReadLong ();
			long moneycua1 = message.reader ().ReadLong ();
			long moneycua2 = message.reader ().ReadLong ();
			long moneycua3 = message.reader ().ReadLong ();
			long moneycua4 = message.reader ().ReadLong ();
			long moneycua5 = message.reader ().ReadLong ();
			XocDiaPlayer pl =  (XocDiaPlayer)GetPlayerWithName (nick);
			if (pl != null) {
				pl.ActionTraTienCuoc (moneycua0, moneycua1, moneycua2, moneycua3, moneycua4, moneycua5);
			}
		} catch (Exception ex) {
			Debug.LogException (ex);
		}
	}

	internal void OnNhanCacMucCuocXD (Message message)
	{
		try {
			long muc1 = message.reader ().ReadLong ();
			long muc2 = message.reader ().ReadLong ();
			long muc3 = message.reader ().ReadLong ();
			long muc4 = message.reader ().ReadLong ();

			txt_bet_money[0].text = MoneyHelper.FormatMoneyNormal(muc1);
			txt_bet_money[1].text = MoneyHelper.FormatMoneyNormal(muc2);
			txt_bet_money[2].text = MoneyHelper.FormatMoneyNormal(muc3);
			txt_bet_money[3].text = MoneyHelper.FormatMoneyNormal(muc4);
			tg_bet_money[0].isOn = true;

		} catch (Exception ex) {
			Debug.LogException (ex);
		}
	}

	internal void OnXocDia_LichSu(Message message) {
		try {
			/*string a = message.reader().ReadUTF();
			if(a.Length <= 0) return;
			string[] chuoi = a.Split(',');
			if (chuoi.Length > 0) {
				for (int i = 0; i < 32; i++) {
					if (i < chuoi.Length) {
						if (int.Parse(chuoi[i]) == 0) {
//							bangLichSu.quan[i].setDrawable(quantrang);
						} else {
//							bangLichSu.quan[i].setDrawable(quando);
						}
//						bangLichSu.quan[i].setVisible(true);
					} else {
//						bangLichSu.quan[i].setVisible(false);
					}
				}
			}
//			bangLichSu.chan.setText("" + _trang);
//			bangLichSu.le.setText("" + _do);
*/
		} catch (Exception ex) {
			Debug.LogException (ex);
		}
	}

	internal void OnXocDia_HuyCua_LamCai(Message message) {
		try {
			sbyte type = message.reader().ReadByte();
			switch (type) {
			case 2:
				// huy cua chan
//				for (MoveMoney money : arrMoveMoneysCUA0) {
//					money.tra_tien();
//				}
//				screen.toast.showToast("Nhà cái hủy của chẵn");
//				arrMoveMoneysCUA0.clear();
				break;
			case 1:
				// huy cua le
//				for (MoveMoney money : arrMoveMoneysCUA1) {
//					money.tra_tien();
//				}
//				arrMoveMoneysCUA1.clear();
//				screen.toast.showToast("Nhà cái hủy của lẻ");
				break;
			}
//			btnHuyCuaChan.setDisabled2(true);
//			btnHuyCuaLe.setDisabled2(true);
		} catch (Exception e) {
		}
	}

}
