﻿using UnityEngine;
using System.Collections;
using System;

public class ServiceException : Exception {
    private static long serialVersionUID = 1L;
}
